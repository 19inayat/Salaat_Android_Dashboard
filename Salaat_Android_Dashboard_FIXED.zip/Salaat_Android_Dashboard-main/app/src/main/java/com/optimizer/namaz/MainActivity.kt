package com.optimizer.namaz

import android.Manifest
import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.RectF
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.sin

data class Segment(
    val name: String,
    val start: Double,
    val end: Double,
    val color: Int
)

data class NamazState(
    val now: Date,
    val currentDec: Double,
    val segments: List<Segment>,
    val currentSegment: Segment?,
    val timerStr: String
)

class LocationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {

        return try {

            val locManager =
                applicationContext.getSystemService(
                    Context.LOCATION_SERVICE
                ) as LocationManager

            val loc =
                locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: locManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

            loc?.let {

                val prefs =
                    applicationContext.getSharedPreferences(
                        "NamazPrefs",
                        Context.MODE_PRIVATE
                    )

                prefs.edit()
                    .putFloat("LAT", it.latitude.toFloat())
                    .putFloat("LNG", it.longitude.toFloat())
                    .apply()
            }

            Result.success()

        } catch (e: Exception) {

            Result.failure()
        }
    }
}

object DataEngine {

    @Volatile
    var state: NamazState? = null

    private var job: Job? = null

    fun start(context: Context) {

        if (job != null) return

        val workReq =
            PeriodicWorkRequestBuilder<LocationWorker>(
                15,
                TimeUnit.MINUTES
            ).build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                "LocTracker",
                ExistingPeriodicWorkPolicy.KEEP,
                workReq
            )

        job = CoroutineScope(Dispatchers.IO).launch {

            while (true) {

                state = calculateState()

                delay(1000)
            }
        }
    }

    private fun calculateState(): NamazState {

        val now = Date()

        val cal = Calendar.getInstance()

        val currentDec =
            cal.get(Calendar.HOUR_OF_DAY) +
                    (cal.get(Calendar.MINUTE) / 60.0) +
                    (cal.get(Calendar.SECOND) / 3600.0)

        val fajr = 5.0
        val sunrise = 6.2
        val dhuhr = 12.5
        val asr = 16.5
        val maghrib = 18.5
        val isha = 19.5

        val segments = listOf(

            Segment(
                "FAJR",
                fajr,
                sunrise,
                android.graphics.Color.parseColor("#FFD54F")
            ),

            Segment(
                "ZUHR",
                dhuhr,
                asr,
                android.graphics.Color.parseColor("#40C4FF")
            ),

            Segment(
                "ASR",
                asr,
                maghrib,
                android.graphics.Color.parseColor("#FF8A65")
            ),

            Segment(
                "ISHA",
                isha,
                fajr + 24,
                android.graphics.Color.parseColor("#37474F")
            )
        )

        var checkTime = currentDec

        if (currentDec < fajr) {
            checkTime += 24.0
        }

        val currentSeg =
            segments.firstOrNull {
                checkTime >= it.start && checkTime < it.end
            }

        val remDec =
            (currentSeg?.end ?: 0.0) - checkTime

        val h = remDec.toInt()

        val m =
            ((remDec - h) * 60).toInt()

        val s =
            ((((remDec - h) * 60) - m) * 60).toInt()

        val timerStr =
            String.format(
                "%02d:%02d:%02d",
                h,
                m,
                s
            )

        return NamazState(
            now = now,
            currentDec = currentDec,
            segments = segments,
            currentSegment = currentSeg,
            timerStr = timerStr
        )
    }
}

object DashboardRenderer {

    fun draw(
        canvas: android.graphics.Canvas,
        width: Int,
        height: Int,
        state: NamazState
    ) {

        canvas.drawColor(
            android.graphics.Color.parseColor("#1D2036")
        )

        val timePaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {

                color = android.graphics.Color.WHITE

                textSize = width * 0.12f

                textAlign = Paint.Align.CENTER
            }

        val timeStr =
            SimpleDateFormat(
                "hh:mm:ss a",
                Locale.US
            ).format(state.now)

        canvas.drawText(
            timeStr,
            width / 2f,
            height * 0.2f,
            timePaint
        )

        val cx = width / 2f
        val cy = height * 0.5f

        val radius = width * 0.35f

        val rect =
            RectF(
                cx - radius,
                cy - radius,
                cx + radius,
                cy + radius
            )

        val arcPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {

                style = Paint.Style.STROKE

                strokeWidth = 60f
            }

        state.segments.forEach {

            val start =
                ((it.start / 24.0) * 360f - 90f).toFloat()

            val sweep =
                (((it.end - it.start) / 24.0) * 360f)
                    .toFloat()

            arcPaint.color = it.color

            canvas.drawArc(
                rect,
                start,
                sweep,
                false,
                arcPaint
            )
        }

        val centerPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {

                color = android.graphics.Color.WHITE

                textSize = width * 0.07f

                textAlign = Paint.Align.CENTER
            }

        canvas.drawText(
            state.currentSegment?.name ?: "--",
            cx,
            cy,
            centerPaint
        )

        canvas.drawText(
            state.timerStr,
            cx,
            cy + 80f,
            centerPaint
        )

        val angle =
            ((state.currentDec / 24.0) * 360.0 - 90.0) *
                    (Math.PI / 180.0)

        val nx =
            cx + cos(angle).toFloat() * (radius - 30)

        val ny =
            cy + sin(angle).toFloat() * (radius - 30)

        val needle =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {

                color = android.graphics.Color.WHITE

                strokeWidth = 8f
            }

        canvas.drawLine(
            cx,
            cy,
            nx,
            ny,
            needle
        )
    }
}

class NamazWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {

        return NamazEngine()
    }

    inner class NamazEngine : Engine() {

        private val handler =
            Handler(Looper.getMainLooper())

        private var visible = false

        private val drawRunner =
            object : Runnable {

                override fun run() {

                    drawFrame()

                    if (visible) {

                        handler.postDelayed(
                            this,
                            1000
                        )
                    }
                }
            }

        override fun onCreate(
            surfaceHolder: SurfaceHolder
        ) {

            super.onCreate(surfaceHolder)

            DataEngine.start(applicationContext)
        }

        override fun onVisibilityChanged(
            isVisible: Boolean
        ) {

            visible = isVisible

            if (visible) {

                handler.post(drawRunner)

            } else {

                handler.removeCallbacks(drawRunner)
            }
        }

        private fun drawFrame() {

            var canvas: android.graphics.Canvas? = null

            try {

                canvas = surfaceHolder.lockCanvas()

                canvas?.let {

                    DataEngine.state?.let { state ->

                        DashboardRenderer.draw(
                            it,
                            it.width,
                            it.height,
                            state
                        )
                    }
                }

            } finally {

                canvas?.let {

                    surfaceHolder.unlockCanvasAndPost(it)
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {

            DataEngine.start(this@MainActivity)
        }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            requestPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )

        } else {

            DataEngine.start(this)
        }

        setContent {

            var trigger by remember {

                mutableStateOf(0)
            }

            LaunchedEffect(Unit) {

                while (true) {

                    delay(1000)

                    trigger++
                }
            }

            Box(
                modifier = Modifier.fillMaxSize()
            ) {

                Canvas(
                    modifier = Modifier.fillMaxSize()
                ) {

                    trigger

                    DataEngine.state?.let {

                        DashboardRenderer.draw(
                            drawContext.canvas.nativeCanvas,
                            size.width.toInt(),
                            size.height.toInt(),
                            it
                        )
                    }
                }

                Button(

                    onClick = {

                        val intent =
                            Intent(
                                WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER
                            ).apply {

                                putExtra(
                                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                    ComponentName(
                                        this@MainActivity,
                                        NamazWallpaperService::class.java
                                    )
                                )
                            }

                        startActivity(intent)
                    },

                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 20.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF353A55)
                    )

                ) {

                    Text(
                        "SET AS LIVE WALLPAPER",
                        color = Color.White
                    )
                }
            }
        }
    }
}
